console.log('StudySync: Extension active');

// Function to find and sync user ID from the hidden DOM element
function syncUserFromDOM() {
  const syncRoot = document.getElementById('studysync-sync-root');
  if (syncRoot && syncRoot.dataset.userId) {
    const userId = syncRoot.dataset.userId;
    chrome.storage.local.get(['userId'], (result) => {
      if (result.userId !== userId) {
        console.log('StudySync: Found userId in DOM, syncing...', userId);
        chrome.storage.local.set({ userId });
      }
    });
  }
}

// Check immediately and then periodically
syncUserFromDOM();
setInterval(syncUserFromDOM, 2000);

// Source detection helper
function getSourceInfo() {
  const url = window.location.href;
  if (url.includes('youtube.com/watch')) {
    const title = document.title.replace(' - YouTube', '');
    return { type: 'youtube', title };
  }
  return null;
}
