const BACKEND_URL = 'http://localhost:5000/api';

// ─── State ────────────────────────────────────────────────────────────────────
let timerInterval = null;
let captureInterval = null;
let sessionStartTime = null;
let currentSessionId = null;
let isRunning = false;
let isVisionActive = false;
let mediaStream = null;
let videoEl = null;
let canvasEl = null;
let localNotes = [];

// ─── DOM refs ─────────────────────────────────────────────────────────────────
const timerEl        = document.getElementById('timer');
const actionBtn      = document.getElementById('action-btn');
const visionBtn      = document.getElementById('vision-btn');
const tabTitleEl     = document.getElementById('tab-title');
const statusDot      = document.getElementById('status-dot');
const lockToggle     = document.getElementById('lock-toggle');
const notesList      = document.getElementById('notes-list');
const notesEmpty     = document.getElementById('notes-empty');
const notesCount     = document.getElementById('notes-count');
const noteInputArea  = document.getElementById('note-input-area');
const noteInput      = document.getElementById('note-input');
const saveNoteBtn    = document.getElementById('save-note-btn');
const syncWarn       = document.getElementById('sync-warn');
const openDashboard  = document.getElementById('open-dashboard');
const sessionBadge   = document.getElementById('session-count-badge');

// ─── Init ─────────────────────────────────────────────────────────────────────
chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
  if (tab) tabTitleEl.textContent = tab.title || 'Unknown tab';
});

chrome.storage.local.get([
  'userId', 'isRunning', 'sessionStartTime', 'activeSessionId',
  'lockedTabId', 'deepFocusEnabled', 'sessionNotes', 'sessionCount'
], (result) => {
  if (!result.userId) {
    syncWarn.style.display = 'block';
  }

  if (result.isRunning) {
    isRunning = true;
    currentSessionId = result.activeSessionId || null;
    sessionStartTime = result.sessionStartTime || Date.now();
    localNotes = result.sessionNotes || [];
    setRunningUI(true);
    startTimer();
    renderNotes();
  }

  if (result.deepFocusEnabled) {
    lockToggle.checked = true;
  }

  const count = result.sessionCount || 0;
  sessionBadge.textContent = `${count} session${count !== 1 ? 's' : ''}`;
});

document.getElementById('sync-link').onclick = () =>
  chrome.tabs.create({ url: 'http://localhost:5173/' });

openDashboard.onclick = () =>
  chrome.tabs.create({ url: 'http://localhost:5173/dashboard/history' });

// ─── Start / Stop ─────────────────────────────────────────────────────────────
actionBtn.addEventListener('click', () => {
  if (!isRunning) startSession();
  else stopSession();
});

async function startSession() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;

  isRunning = true;
  sessionStartTime = Date.now();
  localNotes = [];

  chrome.storage.local.set({ isRunning: true, sessionStartTime, sessionNotes: [] });
  setRunningUI(true);
  startTimer();

  // Notify background to create session in DB
  chrome.runtime.sendMessage({ action: 'startSession', tabId: tab.id }, (resp) => {
    if (resp?.sessionId) {
      currentSessionId = resp.sessionId;
      chrome.storage.local.set({ activeSessionId: resp.sessionId });
    }
  });
}

function stopSession() {
  isRunning = false;
  stopVision();
  clearInterval(timerInterval);
  timerInterval = null;
  timerEl.textContent = '00:00:00';
  setRunningUI(false);

  // Update session count
  chrome.storage.local.get(['sessionCount'], (r) => {
    const newCount = (r.sessionCount || 0) + 1;
    chrome.storage.local.set({ isRunning: false, sessionCount: newCount });
    sessionBadge.textContent = `${newCount} session${newCount !== 1 ? 's' : ''}`;
  });

  chrome.runtime.sendMessage({ action: 'stopSession' });
}

// ─── Timer ────────────────────────────────────────────────────────────────────
function startTimer() {
  timerInterval = setInterval(() => {
    timerEl.textContent = formatTime(Date.now() - sessionStartTime);
  }, 1000);
}

function formatTime(ms) {
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600).toString().padStart(2, '0');
  const m = Math.floor((s % 3600) / 60).toString().padStart(2, '0');
  const sec = (s % 60).toString().padStart(2, '0');
  return `${h}:${m}:${sec}`;
}

// ─── UI State ─────────────────────────────────────────────────────────────────
function setRunningUI(running) {
  if (running) {
    actionBtn.textContent = '■ Stop Session';
    actionBtn.className = 'btn btn-stop';
    visionBtn.style.display = 'flex';
    noteInputArea.style.display = 'flex';
    statusDot.classList.add('active');
    notesEmpty.style.display = 'none';
  } else {
    actionBtn.textContent = '▶ Start Session';
    actionBtn.className = 'btn btn-start';
    visionBtn.style.display = 'none';
    noteInputArea.style.display = 'none';
    visionBtn.textContent = '👁 Start AI Vision';
    visionBtn.classList.remove('active');
    statusDot.classList.remove('active');
    localNotes = [];
    renderNotes();
  }
}

// ─── Deep Focus Lock ──────────────────────────────────────────────────────────
lockToggle.addEventListener('change', async () => {
  const enabled = lockToggle.checked;
  chrome.storage.local.set({ deepFocusEnabled: enabled });

  if (enabled) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) chrome.storage.local.set({ lockedTabId: tab.id });
    chrome.runtime.sendMessage({ action: 'enableDeepFocus' });
  } else {
    chrome.storage.local.remove(['lockedTabId']);
    chrome.runtime.sendMessage({ action: 'disableDeepFocus' });
  }
});

// ─── AI Vision ────────────────────────────────────────────────────────────────
visionBtn.addEventListener('click', () => {
  if (!isVisionActive) startVision();
  else stopVision();
});

async function startVision() {
  try {
    // Request tab capture permission via background
    chrome.runtime.sendMessage({ action: 'captureTab' }, async (dataUrl) => {
      if (chrome.runtime.lastError || !dataUrl) {
        // Fallback: ask user for screen share
        try {
          mediaStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
          videoEl = document.createElement('video');
          videoEl.srcObject = mediaStream;
          await videoEl.play();
          canvasEl = document.createElement('canvas');
        } catch (e) {
          alert('Could not access screen. Please try again.');
          return;
        }
      }
      isVisionActive = true;
      visionBtn.textContent = '👁 AI Vision ON';
      visionBtn.classList.add('active');

      // Capture every 20 seconds
      captureInterval = setInterval(() => runCapture(), 20000);
      // Also run immediately
      runCapture();
    });
  } catch (e) {
    console.error('Vision start failed:', e);
  }
}

function stopVision() {
  isVisionActive = false;
  clearInterval(captureInterval);
  captureInterval = null;
  if (mediaStream) {
    mediaStream.getTracks().forEach(t => t.stop());
    mediaStream = null;
  }
  visionBtn.textContent = '👁 Start AI Vision';
  visionBtn.classList.remove('active');
}

async function runCapture() {
  if (!currentSessionId) return;

  let frameData = null;

  // Try background tab capture first (no permissions dialog)
  frameData = await new Promise((resolve) => {
    chrome.runtime.sendMessage({ action: 'captureTab' }, (dataUrl) => {
      resolve(chrome.runtime.lastError ? null : dataUrl);
    });
  });

  // Fallback to video stream
  if (!frameData && videoEl && canvasEl) {
    canvasEl.width = videoEl.videoWidth || 1280;
    canvasEl.height = videoEl.videoHeight || 720;
    const ctx = canvasEl.getContext('2d');
    ctx.drawImage(videoEl, 0, 0);
    frameData = canvasEl.toDataURL('image/jpeg', 0.6);
  }

  if (!frameData) return;

  try {
    const { userId } = await chrome.storage.local.get(['userId']);
    const uid = userId || 'dev_guest_user';

    const res = await fetch(`${BACKEND_URL}/chat/diagnose?userId=${uid}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        image: frameData,
        context: `Analysing study screen for user studying: ${tabTitleEl.textContent}`,
        sessionId: currentSessionId
      })
    });

    const data = await res.json();
    if (data.notes) {
      addNote({ text: data.notes, image: frameData, type: 'ai', time: new Date().toLocaleTimeString() });
    }
  } catch (e) {
    console.error('Diagnose failed:', e);
  }
}

// ─── Manual Notes ─────────────────────────────────────────────────────────────
saveNoteBtn.addEventListener('click', saveManualNote);
noteInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') saveManualNote(); });

async function saveManualNote() {
  const text = noteInput.value.trim();
  if (!text) return;
  noteInput.value = '';

  addNote({ text, image: null, type: 'manual', time: new Date().toLocaleTimeString() });

  if (!currentSessionId) return;

  try {
    const { userId } = await chrome.storage.local.get(['userId']);
    await fetch(`${BACKEND_URL}/chat/diagnose?userId=${userId || 'dev_guest_user'}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        image: null,
        context: `Voice Note: ${text}`,
        sessionId: currentSessionId
      })
    });
  } catch (e) {
    console.error('Note save failed:', e);
  }
}

// ─── Notes Rendering ──────────────────────────────────────────────────────────
function addNote(note) {
  localNotes.unshift(note);
  chrome.storage.local.set({ sessionNotes: localNotes });
  renderNotes();
}

function renderNotes() {
  notesCount.textContent = localNotes.length;

  if (localNotes.length === 0) {
    notesEmpty.style.display = 'block';
    notesList.querySelectorAll('.note-item').forEach(el => el.remove());
    return;
  }

  notesEmpty.style.display = 'none';
  notesList.querySelectorAll('.note-item').forEach(el => el.remove());

  localNotes.slice(0, 5).forEach(note => {
    const div = document.createElement('div');
    div.className = `note-item${note.image ? ' has-snap' : ''}`;

    const metaEl = document.createElement('div');
    metaEl.className = 'note-meta';
    metaEl.textContent = note.type === 'ai' ? `👁 AI Vision · ${note.time}` : `✏️ Manual · ${note.time}`;
    div.appendChild(metaEl);

    if (note.image) {
      const img = document.createElement('img');
      img.src = note.image;
      img.style.cssText = 'width:100%;border-radius:4px;margin-bottom:4px;max-height:80px;object-fit:cover;';
      div.appendChild(img);
    }

    const textEl = document.createElement('div');
    textEl.textContent = note.text;
    div.appendChild(textEl);

    notesList.appendChild(div);
  });
}
