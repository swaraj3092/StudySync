const BACKEND_URL = 'http://localhost:5000/api';

// ─── Message Router ───────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'startSession') {
    handleStartSession(parseInt(request.tabId))
      .then(id => sendResponse({ sessionId: id }))
      .catch(err => {
        console.error('StudySync: startSession failed', err);
        sendResponse({ error: err.message });
      });
    return true; // keep channel open for async
  }

  if (request.action === 'stopSession') {
    handleStopSession();
    return false;
  }

  if (request.action === 'captureTab') {
    // Capture the visible tab as a JPEG data URL — no dialog needed
    chrome.tabs.captureVisibleTab(null, { format: 'jpeg', quality: 60 }, (dataUrl) => {
      if (chrome.runtime.lastError) {
        sendResponse(null);
      } else {
        sendResponse(dataUrl);
      }
    });
    return true; // async
  }

  if (request.action === 'enableDeepFocus') {
    // Lock stored in storage; onActivated listener enforces it
    return false;
  }

  if (request.action === 'disableDeepFocus') {
    chrome.storage.local.remove(['lockedTabId']);
    return false;
  }
});

// ─── Deep Focus Enforcer ──────────────────────────────────────────────────────
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  const { lockedTabId, deepFocusEnabled } = await chrome.storage.local.get(['lockedTabId', 'deepFocusEnabled']);
  if (!deepFocusEnabled || !lockedTabId) return;

  const locked = parseInt(lockedTabId);
  if (activeInfo.tabId !== locked) {
    try {
      await chrome.tabs.update(locked, { active: true });
      notify('🔒 Deep Focus Active', 'Stay focused! Finish your session to switch tabs.');
    } catch (e) {
      // Tab may be dragging or already closed — ignore
      console.warn('Deep Focus: could not switch tab:', e.message);
    }
  }
});

// ─── Session: Create in DB ────────────────────────────────────────────────────
async function handleStartSession(providedTabId) {
  let tabId = providedTabId;

  // Fallback if no valid tabId provided
  if (!tabId || isNaN(tabId)) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    tabId = tab?.id;
  }
  if (!tabId) throw new Error('No active tab found');

  const tab = await chrome.tabs.get(tabId);
  const startTime = Date.now();

  await chrome.storage.local.set({
    lockedTabId: tabId,
    sessionStartTime: startTime,
  });

  const { userId } = await chrome.storage.local.get(['userId']);

  const body = {
    title: tab.title?.replace(' - YouTube', '') || 'Study Session',
    url: tab.url || '',
    sourceType: detectSourceType(tab.url || ''),
    startTime: new Date(startTime).toISOString(),
    status: 'active',
    userId: userId || 'dev_guest_user',
    notes: [],
    tasksCount: 0
  };

  const resp = await fetch(`${BACKEND_URL}/sessions/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });

  const data = await resp.json();
  await chrome.storage.local.set({ activeSessionId: data._id });
  return data._id;
}

// ─── Session: Complete in DB ──────────────────────────────────────────────────
async function handleStopSession() {
  const { activeSessionId, sessionStartTime } = await chrome.storage.local.get(['activeSessionId', 'sessionStartTime']);
  if (!activeSessionId) return;

  const durationMs = Date.now() - (sessionStartTime || Date.now());

  try {
    await fetch(`${BACKEND_URL}/sessions/${activeSessionId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        status: 'completed',
        duration: formatDuration(durationMs),
        endTime: new Date().toISOString()
      }),
    });
    notify('✅ Session Complete', 'Great work! Your session is saved to StudySync.');
  } catch (err) {
    console.error('StudySync: stopSession failed', err);
  } finally {
    await chrome.storage.local.remove(['activeSessionId', 'sessionStartTime', 'lockedTabId', 'deepFocusEnabled']);
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function detectSourceType(url) {
  if (url.includes('youtube.com')) return 'youtube';
  if (url.endsWith('.pdf') || url.includes('pdf')) return 'pdf';
  return 'article';
}

function formatDuration(ms) {
  const min = Math.floor(ms / 60000);
  if (min < 1) return '1m';
  const h = Math.floor(min / 60);
  const m = min % 60;
  return h > 0 ? `${h}h ${m}m` : `${min}m`;
}

function notify(title, message) {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title,
    message
  });
}
